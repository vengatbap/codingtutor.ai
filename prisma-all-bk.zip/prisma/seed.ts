// import { PrismaClient } from "@prisma/client";

// const prisma = new PrismaClient();

// async function main() {
//   const lessons = [
//     {
//       id: "js-functions-1",
//       title: "What is a JavaScript Function?",
//       description: "Understand functions in simple terms",
//       content: `
// A function is a reusable block of code.

// // Why functions matter:
// - Avoid repetition
// - Organize logic
// - Improve readability

// Example:
// function greet(name) {
//   return "Hello " + name;
// }
// `,
//       language: "JavaScript",
//       level: "beginner",
//       order: 1,
//     },
//     {
//       id: "js-variables-1",
//       title: "JavaScript Variables",
//       description: "Learn how to store values",
//       content: `
// Variables store data values.

// Common keywords:
// - let
// - const
// - var (old)

// Example:
// let age = 25;
// const name = "John";
// `,
//       language: "JavaScript",
//       level: "beginner",
//       order: 2,
//     },
//   ];

//   for (const lesson of lessons) {
//     await prisma.lesson.upsert({
//       where: { id: lesson.id },
//       update: lesson,
//       create: lesson,
//     });
//   }

//   console.log("✅ Lessons seeded");
// }

// main()
//   .catch((e) => {
//     console.error(e);
//     process.exit(1);
//   })
//   .finally(async () => {
//     await prisma.$disconnect();
//   });
